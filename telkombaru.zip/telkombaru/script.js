let data = JSON.parse(localStorage.getItem("gudang")) || [];

function render() {
  const tabel = document.getElementById("tabel-data");
  tabel.innerHTML = "";
  data.forEach((d, i) => {
    tabel.innerHTML += `
      <tr>
        <td>${i + 1}</td>
        <td>${d.barang}</td>
        <td>${d.jumlah}</td>
        <td>${d.jenis}</td>
        <td>${d.pengambil}</td>
        <td>${d.waktu}</td>
        <td><button onclick="hapus(${i})">🗑️ Hapus</button></td>
      </tr>
    `;
  });
}

function hapus(i) {
  data.splice(i, 1);
  simpan();
}

function simpan() {
  localStorage.setItem("gudang", JSON.stringify(data));
  render();
}

document.getElementById("form").addEventListener("submit", function (e) {
  e.preventDefault();
  const barang = document.getElementById("barang").value;
  const jumlah = document.getElementById("jumlah").value;
  const jenis = document.getElementById("jenis").value;
  const pengambil = document.getElementById("pengambil").value;
  const waktu = new Date().toLocaleString();
  data.push({ barang, jumlah, jenis, pengambil, waktu });
  simpan();
  this.reset();
});

function gantiMode(mode) {
  document.body.className = "";
  if (mode === "malam") document.body.classList.add("mode-malam");
  else if (mode === "kece") document.body.classList.add("mode-kece");
  else if (mode === "cool") document.body.classList.add("mode-cool");
}

render();
