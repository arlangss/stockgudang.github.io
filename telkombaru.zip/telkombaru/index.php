<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>STOCK GUDANG by ARLANGSS</title>
  <link rel="stylesheet" href="style.css" />
</head>
<body>
  <h1>STOCK GUDANG by ARLANGSS</h1>

  <div class="mode-toggle">
    <button onclick="gantiMode('malam')">🌙 Malam</button>
    <button onclick="gantiMode('kece')">😎 Kece</button>
    <button onclick="gantiMode('cool')">🧊 Cool</button>
  </div>

  <form id="form">
    <select id="barang">
      <option disabled selected>-- Pilih Barang --</option>
      <option>Kabel UTP</option>
      <option>Modem ZTE</option>
      <option>Baut Fiber</option>
      <option>Kabel FO</option>
      <option>Switch Hub</option>
    </select>
    <input type="number" id="jumlah" placeholder="Jumlah" required />
    <select id="jenis">
      <option value="masuk">Masuk</option>
      <option value="keluar">Keluar</option>
    </select>
    <input type="text" id="pengambil" placeholder="Nama Pengambil" required />
    <button type="submit">➕ Tambah</button>
  </form>

  <table>
    <thead>
      <tr>
        <th>No</th>
        <th>Nama Barang</th>
        <th>Jumlah</th>
        <th>Jenis</th>
        <th>Nama Pengambil</th>
        <th>Waktu</th>
        <th>Aksi</th>
      </tr>
    </thead>
    <tbody id="tabel-data"></tbody>
  </table>

  <script src="script.js"></script>
</body>
</html>
